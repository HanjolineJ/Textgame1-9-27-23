public class Action {
    public static boolean move(String direction, Player player, GameMap map) {
        Room nextRoom = map.getRoom(player.getLocation(), direction);
        if (nextRoom == null) {
            return false;
        } else {
            player.setLocation(nextRoom);
            return true;
        }
    }

    public static boolean use(String item, Player player) {
        for (Item i : player.getInventory()) {
            if (i.getName().equals(item)) {
                player.removeItem(i);
                return true;
            }
        }
        return false;
    }

    public static boolean fight(String monster) {
        if (monster == null) {
            return false;
        } else {
            return true;
        }

        }

        //if (result2) {
        //  System.out.println("You will run from the monster!");
        //return true;
        //}
        //else {
        //  System.out.println("You will fight the monster!");
        //return true;
        //}


}


