import java.util.Random;

public class Monster {
    public String getDamage;
    public String getName;
    private String name;
    private float health;
    private int damage;
    private Random r = new Random();


    public Monster() {
        this.name = name;
        this.health = 20.0f;
        this.damage = r.nextInt(1, 10);
    }

    public void setHealth(float health) {
        this.health = health;
    }

    public float getHealth() {
        return this.health;
    }

    public void setName() {
        String[] choices = {"spider", "zombie", "wolf", "bull"};
        Random r = new Random();
        this.name = choices[r.nextInt(choices.length)];
    }
    // Method to get the name
    public String getName() {
        return this.name;
    }

    public void setDamage(int damage) {
        this.damage = damage;

    }

    public int getDamage() {
        return this.damage;
    }
}
