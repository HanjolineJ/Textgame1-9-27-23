public class Inventory {
        private Item[] items;
        private int itemCount;
/*
        public Inventory() {
            this.items = new Item[2]; // Initialize the inventory with space for 2 items
            this.itemCount = 0; // Initialize the item count to 0
        }

        public void addItem(Item item) {
            if (itemCount < items.length) {
                items[itemCount] = item;
                itemCount++;
                System.out.println(item.getName() + " has been added to the inventory.");
            } else {
                System.out.println("Inventory is full. Cannot add " + item.getName());
            }
        }

        public void removeItem(int index) {
            if (index >= 0 && index < itemCount) {
                Item removedItem = items[index];
                items[index] = null;
                itemCount--;
                System.out.println(removedItem.getName() + " has been removed from the inventory.");
            } else {
                System.out.println("Invalid index. No item removed.");
            }
        }

        public void listItems() {
            System.out.println("Inventory Items:");
            for (Item item : items) {
                if (item != null) {
                    System.out.println(item.getName());
                }
            }
        }
    }
*/

    public Inventory(int capacity) {
        this.items = new Item[capacity];
        this.itemCount = 0;
    }

    public boolean addItem(Item item) {
        if (itemCount < items.length) {
            items[itemCount] = item;
            itemCount++;
            System.out.println(item.getName() + " has been added to the inventory.");
            return true;
        } else {
            System.out.println("Inventory is full. Cannot add " + item.getName());
            return false;
        }
    }

    public void removeItem(int index) {
        if (index >= 0 && index < itemCount) {
            Item removedItem = items[index];
            items[index] = null;
            itemCount--;
            System.out.println(removedItem.getName() + " has been removed from the inventory.");
        } else {
            System.out.println("Invalid index. No item removed.");
        }
    }

    public void listItems() {
        System.out.println("Inventory Items:");
        for (Item item : items) {
            if (item != null) {
                System.out.println(item.getName());
            }
        }
    }
}