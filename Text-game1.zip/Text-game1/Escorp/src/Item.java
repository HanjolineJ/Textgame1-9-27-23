public class Item {

    private static int swordHurt = 15;
    private static int shieldHurt = 10;
    private static int potionHurt = 7;

    public static int getSwordHurt() {
        return swordHurt;
    }


    public static int getShieldHurt() {
        return shieldHurt;
    }


    public static int getPotionHurt() {
        return potionHurt;
    }


    private String name;
    



    public Item(String name) {
        this.name = name;
    }



    public String getName() {
        return this.name;
    }

    public String toString() {
        return this.name;
    }
}
