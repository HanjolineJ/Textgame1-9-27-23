
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
//room algorimithan with monster check
//monster class loop attack or run
    public class Main {

        public static void main(String[] args) {
            GameMap game_map = new GameMap();
            Room dungeon = new Room("Dungeon", "A dark and damp dungeon.");
            Room cave = new Room("Cave", "A dark and damp cave.");
            Room forest = new Room("Forest", "A dark and damp forest.");
            Room castle = new Room("Castle", "A dark and damp castle.");
            Room tower = new Room("Tower", "A dark and damp tower.");
            Room beach = new Room("Beach", "A dark and damp beach.");
            // Rooms and descriptions

            game_map.linkRoom(dungeon, "n", cave);
            game_map.linkRoom(cave, "s", dungeon);
            game_map.linkRoom(cave, "e", forest);
            game_map.linkRoom(forest, "w", cave);
            game_map.linkRoom(forest, "n", castle);
            game_map.linkRoom(castle, "s", forest);
            game_map.linkRoom(castle, "e", tower);
            game_map.linkRoom(tower, "w", castle);
            game_map.linkRoom(tower, "n", beach);
            game_map.linkRoom(beach, "s", tower);
            // Links rooms together
// put befrote
            ObjectMapper mapper = new ObjectMapper();
            try{
                Map<?,?> game1 = mapper.readValue(
                        new File("game1.json"), Map.class);
                System.out.println(game1);
                System.out.println(game1.get("player"));
                Map<?,?> playerdata = (Map<?,?>) game1.get("player");
                System.out.println(playerdata.get("name"));
                List<?> allrooms = (List<?>) game1.get("rooms");
                System.out.println(allrooms);
                for (Object room : allrooms) {
                    Map<?, ?> roomdata = (Map<?, ?>) room;
                    Map<?, ?> roomExits = (Map<?, ?>) ((Map<?, ?>) room).get("exits");
                    String name = (String) ((Map<?, ?>) room).get("name");
                    String description = (String) ((Map<?, ?>) room).get("description");
                    Room room_obj = new Room(name, description);

                    for (Object e : roomExits.keySet()) {
                        String es = (String) e;
                        String room_name = (String) roomExits.get(es);
                    }
                }
            } catch(Exception e){
                    System.out.println(e);
            }

            Player player = new Player();
            player.setName("Player");
            player.setHealth(100.0f);
            player.addItem(new Item("sword"));
            player.addItem(new Item("shield"));
            player.addItem(new Item("potion"));
            // Player and items


            Monster monster = new Monster();
            monster.setName(); // Call setName() to set the name
            monster.setHealth(20.0f);
            monster.setDamage(10);
            // Monster
            for (Item item : player.getInventory()) {
                System.out.println(item.getName());
            }
            // Lists items

            String health = player.getHealth() - monster.getDamage() + "";
            // equation for health

            System.out.println("Welcome to the game!");
            System.out.println("You have " + player.getHealth() + " health.");
            System.out.println("You have the following items:");
            // Introductory text

            player.setLocation(beach);
            System.out.println("You are in this room " + player.getLocation());
            System.out.println("What direction do you want to go: South (s), East (e), North (n), or West (w)");
            while (true) {
                Scanner input = new Scanner(System.in);
                String direction = input.nextLine().toLowerCase();

                if (direction.equals("s") || direction.equals("e") || direction.equals("n") || direction.equals("w")) {
                    Action.move(direction, player, game_map);
                    System.out.println("You are in the " + player.getLocation());
                } else {
                    System.out.println("Invalid input. Enter s, e, n, or w to move.");
                }



                System.out.println("You take 4 steps and see a flashlight on the ground. Do you want to pick it up? (y) (n)");
                String flashlight = input.nextLine().toLowerCase();
                while (true) {
                    if (flashlight.equals("y")) {
                        player.addItem(new Item("flashlight"));
                        System.out.println("Now you can see in the dark!");
                        System.out.println("You have the following items:");
                        for (Item item : player.getInventory()) {
                            System.out.println(item.getName());
                        }
                        break;
                    } else if (flashlight.equals("n")) {
                        System.out.println("You continue walking.");
                        break;
                    } else {
                        System.out.println("Invalid input. Enter y or n.");
                    }
                }

                System.out.println("You walk 4 more steps and see a monster. Do you want to fight it? (y) (n)");
                while (true) {
                    String fight = input.nextLine().toLowerCase();
                    if (fight.equals("y")) {
                        System.out.println("You will fight the monster! Enter the item you want to attack with:" + player.getInventory() + ".");
                        String attackItem = input.nextLine().toLowerCase();
                        if (attackItem.equals("sword")) {
                            System.out.println("You attack the " + monster.getName() + " with your sword. DO YOUR WORST!");
                            System.out.println("You hit the " + monster.getName() + " and it loses " + Item.getSwordHurt() + " health.");
                            System.out.println("The monster is a " + monster.getName() + " and has " + (monster.getHealth() - Item.getSwordHurt()) + " health left."
                                    + " The monster does " + monster.getDamage() + " damage.");
                            System.out.println("You have " + health + " health left.");
                            break;
                        } else if (attackItem.equals("shield")) {
                            System.out.println("You attack the monster with your shield. DO YOUR WORST!");
                            System.out.println("You hit the " + monster.getName() + " and it loses " + Item.getShieldHurt() + " health.");
                            System.out.println("The " + monster.getName() + " and has " + (monster.getHealth() - Item.getShieldHurt()) + " health left."
                                    + " The monster does " + monster.getDamage() + " damage.");
                            System.out.println("You have " + health + " health left.");
                            break;
                        } else if (attackItem.equals("potion")) {
                            System.out.println("You attack the monster with your potion. DO YOUR WORST!");
                            System.out.println("You hit the " + monster.getName() + " and it loses " + Item.getPotionHurt() + " health.");
                            System.out.println("The " + monster.getName() + " and has " + (monster.getHealth() - Item.getPotionHurt()) + " health left."
                                    + " The monster does " + monster.getDamage() + " damage.");
                            System.out.println("You have " + health + " health left.");
                            break;
                        } else {
                            System.out.println("Invalid input. Enter sword, shield, or potion.");
                        }
                    } else if (fight.equals("n")) {
                        System.out.println("You choose not to fight and sneak away to another direction.");
                        System.out.println("You are in this room " + player.getLocation());
                        System.out.println("What direction do you want to go: South (s), East (e), North (n), or West (w)");
                        while (true) {
                            //Scanner inputsneak = new Scanner(System.in);
                            String directionsneak = input.nextLine().toLowerCase();
                            if (directionsneak.equals("s") || directionsneak.equals("e") || directionsneak.equals("n") || directionsneak.equals("w")) {
                                Action.move(directionsneak, player, game_map);
                                System.out.println("You are in the room: " + player.getName() + " " + player.getLocation());
                            } else {
                                System.out.println("Invalid input. Enter s, e, n, or w to move.");
                            }
                            break;
                        }
                            //else if that is not y or n then say invalid input
                        } else{
                            System.out.println("Invalid input. Enter y or n.");
                        }
                    }
                }
            }
        }





// go into rooms, see if any items to pick up, use items, fight monsters, get to the end of the game
// use loops to check if you have items, check if you have health, check if you have won
// when picking up items or lamps, check if you have inventory space or if you have a lamp and make a class for this
// say go N S E W, Say pick up or put down, say use item, say fight, becareful with word choice
//comment code and explain what it does!!!!

